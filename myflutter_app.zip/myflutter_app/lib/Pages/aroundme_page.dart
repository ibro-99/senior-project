import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:myflutter_app/intro.dart';
import 'package:latlong/latlong.dart';
import 'package:geolocation/geolocation.dart';




class AroundmePage extends StatefulWidget{
 AroundmePage({key}) : super(key: key);

@override
_AroundmePageState createState() => _AroundmePageState();

}

class _AroundmePageState extends State<AroundmePage> {
  MapController controller = new MapController();
/*
  getPermission() async {
    final GeolocationResult result = await Geolocation.requestLocationPermission(
      permission: const LocationPermission(
        android: LocationPermissionAndroid.fine,
        ios: LocationPermissionIOS.always,
     ));
    return result;
  }

  getLocation() {
    return getPermission().then((result) async{
      if (result.isSuccesful) {
         final coords = await Geolocation.currentLocation(accuracy: LocationAccuracy.best);
         return coords;
      }
    });
  }

  buildMap() {
    getLocation().then((response) {
      if (response.isSuccesful) {
        response.listen((value) {
          controller.move(new LatLng(value.location.latitude, value.location.longtitude), 15.0);
        });
      }
    });
  }
  */

  @override
  Widget build(BuildContext context){
  return Scaffold(
    
    appBar: AppBar(
      title: Text('Around Me'),
      ),
      body: new FlutterMap(
        options: new MapOptions(
          center: new LatLng(40.71, -74.00), minZoom: 10.0),
         // center: buildMap(), minZoom: 5.0),
          layers: [
            new TileLayerOptions(
              urlTemplate:
              "https://api.mapbox.com/styles/v1/ibro99/ckju0zgmj0h0h19qnl7ry3cun/tiles/256/{z}/{x}/{y}@2x?access_token=pk.eyJ1IjoiaWJybzk5IiwiYSI6ImNraWo5aHB2bDAwa3MydG56dXkybmp3NmcifQ.3Kdvh1kOoQGYronCwn1oiw",
              additionalOptions: {
                'accesToken': 'pk.eyJ1IjoiaWJybzk5IiwiYSI6ImNraWo5aHB2bDAwa3MydG56dXkybmp3NmcifQ.3Kdvh1kOoQGYronCwn1oiw',
                'id': 'mapbox.mapbox-streets-v8'
              }
            ),

            new MarkerLayerOptions(markers: [
              new Marker(
                width: 45.0,
                height: 45.0,
                point: new LatLng(40.73, -74.00),
                builder: (context) => new Container(
                  child: IconButton(
                    icon: Icon(Icons.location_on),
                    color: Colors.red,
                    iconSize: 45.0,
                    onPressed: () {
                      print('Marker Tapped');
                    },
                    ),
                )
              )
            ])
          ], 

           )
        
      );
      

  }

  
}